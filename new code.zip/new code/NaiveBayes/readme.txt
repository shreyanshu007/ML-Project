# Naive Bayes

Required files

    reader.py
    train.csv

    File that will be generated :
        train_data.npy
        prior.npy
        frequency_dict.npy

    These file will be generated and will be required further calculations


To run:
    python3 reader.py
