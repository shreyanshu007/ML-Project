import csv 
import nltk
import numpy as np
import math

selected_tags = ['javascript', 'php', 'c#', 'java', 'python', 'ruby', 'jquery', 'objective-c', 'asp.net', 'android', 'arrays', 'ruby-on-rails', 'c', 'vb.net', 'c++', 'mysql', 'ios', '.net', 'json', 'html']
# selected_tags = np.load('top_20_tags.npy')

# Taking frequency of word and total sum of frequency as input and returns log of probability of that word
def returns_probability(freq, total_freq):
	m = 1000
	p = 1
	return math.log((freq + p) / (total_freq + m))

def return_train_data_count(file_name):
	f = open(file_name, encoding="utf8")
	reader = csv.reader(f, delimiter=',')

	train_data_count = 0

	# skipping the first line(heading)
	for heading in reader:
		break

	for count in reader:
		train_data_count += 1

	return train_data_count - 3000



# Reading training data from csv file and storing them in dictionary
# dict : key -> tag
# 		 value - > list of word corresponds to that tag

def read_train_data(file_name):

	# Main dictionary that stores all the train data
	dict =  {}
	# Dictionary contains tags with their number of occurance
	prior = {}
	choice = 1
	if choice == 0:
		id_with_question = np.load('id_with_question.npy').item()
		id_with_tag = np.load('id_with_tag.npy').item()

		for qest in id_with_question.keys():
			temp_list = []
			for wro in nltk.pos_tag(id_with_question[qest][0].split()):
				if(wro[1] == 'NNP' or wro[1] == 'NNS' or wro[1] == "NN" or wro[1] == "NNPS"):
					# word_list.append(wro[0])
					temp_list.append(wro[0])


			for tag in id_with_tag[qest]:
				# tag_list.append(tag)
				if tag in selected_tags:
					if tag in dict.keys():
						dict[tag] = dict[tag] + temp_list
					else:
						dict[tag] = temp_list

					# Calculating prior
					if tag in prior.keys():
						prior[tag] += 1
					else:
						prior[tag] = 1

		# print(selected_tags)
	elif choice == 1:
		f = open(file_name, encoding="utf8")
		reader = csv.reader(f, delimiter=',')

		# skipping the first line(heading)
		for heading in reader:
			break


		for line in reader:
			temp_list = []
			for wro in nltk.pos_tag(line[0].split()):
				if(wro[1] == 'NNP' or wro[1] == 'NNS' or wro[1] == "NN" or wro[1] == "NNPS"):
					# word_list.append(wro[0])
					temp_list.append(wro[0])


			# Taking out all the tags from a line
			temp = line[1]
			temp = temp[2:len(temp)-2]
			tokens = temp.split('\', \'')

			flag = 0
			for tagg in tokens:
				if tagg in selected_tags:
					flag = 1

			if flag == 0:
				continue

			# Storing values in the main dictionary
			for tag in tokens:
				# tag_list.append(tag)
				if tag in selected_tags:
					if tag in dict.keys():
						dict[tag] = dict[tag] + temp_list
					else:
						dict[tag] = temp_list

					# Calculating prior
					if tag in prior.keys():
						prior[tag] += 1
					else:
						prior[tag] = 1


	# print("prior ", len(prior))
	# print("dict ", len(dict))

	# Saving the dictionary into a file
	np.save('train_data.npy', dict)
	np.save('prior.npy', prior)



# storing frequencies of all words in tag
def frequency_dictionary():
	# key = tag
	# value = dict : 	key = word
	# 					value = frequency
	frequency_dict = {}


	# Loading the dictionary from the file
	read_dictionary = np.load('train_data.npy').item()


	for key in read_dictionary.keys():
		word_freq = {}

		for wrd in set(read_dictionary[key]):
			word_freq[wrd] = 0

		for wrd in read_dictionary[key]:
			if wrd in word_freq.keys():
				word_freq[wrd] += 1
			else:
				word_freq[wrd] = 1

		frequency_dict[key] = word_freq

	np.save('frequency_dict.npy', frequency_dict)



# Returns the sum of all frequency
def returns_sum_of_frequencies(frequency_dict):
	sum_of_frequencies = 0
	for key in frequency_dict.keys():
		for k in frequency_dict[key].keys():
			sum_of_frequencies += frequency_dict[key][k]

	# print("sum", sum_of_frequencies)
	return sum_of_frequencies





# Calling the functions
read_train_data("train.csv")
frequency_dictionary()

# Loading the dictionary
frequency_dict = np.load('frequency_dict.npy').item()
prior = np.load('prior.npy').item()

# print("prior", prior)

sum_of_frequency = returns_sum_of_frequencies(frequency_dict)
train_data_count = return_train_data_count('train.csv')


# print(train_data_count, " count")

# cat = ['iphone', 'terminal']

def predict(list_name, list_freq,  frequency_dict, sum_of_frequencies, prior, train_data_count):
	tag_prob = []
	tag_list = []

	for key in frequency_dict.keys():
		# print(key)
		tag_list.append(key)
		frequency_sum = math.log(prior[key]/train_data_count)
		for word in list_name:
			if word in frequency_dict[key].keys():
				frequency_sum += returns_probability(frequency_dict[key][word], sum_of_frequencies)
				frequency_sum += math.log(list_freq[list_name.index(word)])
		tag_prob.append(frequency_sum)


	# print("predicted", (tag_list[tag_prob.index(min(tag_prob))]))

	spam_ind = (sorted(range(len(tag_prob)), key=lambda i: tag_prob[i], reverse=False)[:5])
	return spam_ind, tag_list
	# for indi in spam_ind:
	# 	print("predicted tag", tag_list[indi])


	# return (tag_list[tag_prob.index(min(tag_prob))])
	# print(tag_prob)


correct = 0
wrong = 0
choice = 1

confusion_matrix = np.zeros(shape=(20,20), dtype=int)
# [actual][predicted]

if choice == 0:
	id_with_question = np.load('id_with_question.npy').item()
	id_with_tag = np.load('id_with_tag.npy').item()

	for qest in id_with_question.keys():
		temp_list = []
		for wro in nltk.pos_tag(id_with_question[qest][0].split()):
			if(wro[1] == 'NNP' or wro[1] == 'NNS' or wro[1] == "NN" or wro[1] == "NNPS"):
				# word_list.append(wro[0])
				temp_list.append(wro[0])


		test_freq = []
		temp_list1 = list(set(temp_list))
		for chk in temp_list1:
			test_freq.append(0)

		for valu in temp_list:
			test_freq[temp_list1.index(valu)] += 1

		# print(temp_list)
		# print(temp_list1)
		# print(test_freq)

		# Taking out all the tags from a line


		# print("\nactual tag", tokens)
		flag = 0
		for tagg in id_with_tag[qest]:
			if tagg in selected_tags:
				flag = 1

		if flag == 0:
			continue

		x, y = predict(temp_list1, test_freq, frequency_dict, sum_of_frequency, prior,train_data_count)
		# print(x[1])

		if y[x[0]] in id_with_tag[qest] or y[x[1]] in id_with_tag[qest] or y[x[2]] in id_with_tag[qest] or y[x[3]] in id_with_tag[qest] or y[x[4]] in id_with_tag[qest]:
			correct += 1
		else:
			wrong += 1

elif choice == 1:

	f = open("train.csv", encoding="utf8")
	reader = csv.reader(f, delimiter=',')

	# skipping the first line(heading)
	for heading in reader:
		break

	inti = 0

	for line in reader:
		temp_list = []
		for wro in nltk.pos_tag(line[0].split()):
			if(wro[1] == 'NNP' or wro[1] == 'NNS' or wro[1] == "NN"):
				# word_list.append(wro[0])
				temp_list.append(wro[0])

		test_freq = []
		temp_list1 = list(set(temp_list))
		for chk in temp_list1:
			test_freq.append(0)

		for valu in temp_list:
			test_freq[temp_list1.index(valu)] += 1

		# print(temp_list)
		# print(temp_list1)
		# print(test_freq)

		# Taking out all the tags from a line
		temp = line[1]
		temp = temp[2:len(temp)-2]
		tokens = temp.split('\', \'')

		# print("\nactual tag", tokens)
		flag = 0
		for tagg in tokens:
			if tagg in selected_tags:
				flag = 1

		if flag == 0:
			continue

		x, y = predict(temp_list1, test_freq, frequency_dict, sum_of_frequency, prior, train_data_count)
		# print(x[1])

		flg = 0

		if y[x[0]] in tokens:
			correct += 1
			flg = 1
			confusion_matrix[selected_tags.index(y[x[0]])][selected_tags.index(y[x[0]])] += 1
		if y[x[1]] in tokens:
			correct += 1
			flg = 1
			confusion_matrix[selected_tags.index(y[x[0]])][selected_tags.index(y[x[0]])] += 1
		if y[x[2]] in tokens:
			correct += 1
			flg = 1
			confusion_matrix[selected_tags.index(y[x[0]])][selected_tags.index(y[x[0]])] += 1
		if y[x[3]] in tokens:
			correct += 1
			flg = 1
			confusion_matrix[selected_tags.index(y[x[0]])][selected_tags.index(y[x[0]])] += 1
		if y[x[4]] in tokens:
			correct += 1
			flg = 1
			confusion_matrix[selected_tags.index(y[x[0]])][selected_tags.index(y[x[0]])] += 1
		if flg == 0:
			wrong += 1
			for tagg in tokens:
				if tagg in selected_tags:
					# print(x)
					confusion_matrix[selected_tags.index(y[x[0]])][selected_tags.index(tagg)] += 1
					break

		# inti += 1
		# if inti > 1000:
		# 	break


# print(confusion_matrix)
for i in range(20):
	for j in range(20):
		print(confusion_matrix[i][j], end = '\t')
	print("\n")


print("Accuracy", correct * 100 / (wrong + correct))

#
# unique_tag_list = list(set(tag_list))
# noun_word_list = list(set(word_list))
#
# tag_frequency_list = []
#
# for m in unique_tag_list:
# 	tag_frequency_list.append(0)
#
# # for crap in reader1:
# # 	break
#
# for line in raw_data:
# 	temp = line[1]
# 	temp = temp[2:len(temp)-2]
# 	tokens = temp.split('\', \'')
#
# 	for tag in tokens:
# 		tag_frequency_list[unique_tag_list.index(tag)] += 1
#
#
#
# print (i)
# print (len(unique_tag_list))
# print (len(noun_word_list))
#
# print(tag_frequency_list)
# print(unique_tag_list)
#
